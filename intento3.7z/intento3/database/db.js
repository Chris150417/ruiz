const mysql = require('mysql');
const connnecion = mysql.createConnection({ 
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database:  "logindb"
});
connnecion.connect((error)=>{
    if(error){
        console.log(error);
        return;
    }else{
        console.log('Conexión exitosa');
    }
});
module.exports = connnecion;