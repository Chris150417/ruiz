const express = require('express');
const app = express();
const path = require('path');
const multer = require('multer');
app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, 'src/views'));

const storage = multer.diskStorage({
    destination: path.join(__dirname, 'src/public/uploads'),
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }

});
app.set('view engine', 'ejs');

app.use(express.static(path.join(__dirname, 'src/public')));



//Antes de las rutas para que guarde
app.use(multer({
    storage,
    dest: path.join(__dirname, '/src/public/uploads'),
    fileFilter: (req, file, cb) => {
        const filetypes = /jpeg|jpg|png/;
        const mimetype = filetypes.test(file.mimetype);
        const extname = filetypes.test(path.extname(file.originalname));
        if (mimetype && extname) {
            return (cb(null, true));
        }
        cb();
    }
}).single('img'));

//Captura de datos
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const dotenv = require('dotenv');
dotenv.config({ path: './env/.env' });

const bdcryptjs = require('bcryptjs');

const connection = require('./database/db');

const session = require('express-session');
const bcryptjs = require('bcryptjs');
const exp = require('constants');
app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
}))

app.post('/register', async (req, res) => {
    const user = req.body.user;
    const pass = req.body.pass;
    const name = req.body.name;
    const role = 'client';
    let passwordHaash = await bdcryptjs.hash(pass, 8);
    connection.query('SELECT * FROM users WHERE user=?', [user], (error, results) => {
        if (results.length == 0) {
            connection.query('INSERT INTO users SET ?', { user: user, name: name, pass: passwordHaash, role: role }, async (error, results) => {
                if (error) {
                    res.send('error')
                    console.log(error);
                } else {
                    res.render('register', {
                        alert: true,
                        alertTitle: "Regitro exitoso",
                        alertMessage: "Usuario registrado",
                        alertIcon: 'success',
                        showConfirmButton: 'false',
                        timer: 1500,
                        ruta: 'login',
                        login: false,
                        role: '',
                        pag: 'true'
                    });

                }
            });

        } else {
            console.log(results);
            res.render('register', {
                alert: true,
                alertTitle: "Error",
                alertMessage: "Nombre de usuario repetido",
                alertIcon: 'error',
                showConfirmButton: 'true',
                timer: false,
                ruta: 'register',
                login: false,
                role: req.session.role,
                pag: 'true'
            });
        }
    });


});

app.post('/auth', async (req, res) => {
    const user = req.body.user;
    const pass = req.body.pass;
    let passwordHaash = await bcryptjs.hash(pass, 8);
    if (user && pass) {
        connection.query('SELECT * FROM users WHERE user= ?', [user], async (error, results) => {
            if (results.length == 0 || !(await bcryptjs.compare(pass, results[0].pass))) {
                res.render('login', {
                    alert: true,
                    alertTitle: "Error",
                    alertMessage: "Usuario o contraseña incorrectos",
                    alertIcon: 'error',
                    showConfirmButton: 'true',
                    timer: false,
                    ruta: 'login',
                    login: false,
                    role: req.session.role,
                    pag: 'true'
                });
            } else {
                req.session.loggedin = true;
                req.session.name = results[0].name
                req.session.role = results[0].role
                res.render('login', {
                    alert: true,
                    alertTitle: "Bienvenido!",
                    alertMessage: "",
                    alertIcon: 'success',
                    showConfirmButton: 'false',
                    timer: 1500,
                    ruta: '/',
                    login: false,
                    role: req.session.role,
                    pag: 'true'
                });
            }
        });
    } else {
        res.render('login', {
            alert: true,
            alertTitle: "Error",
            alertMessage: "Ingrese  un usuario o contraseña ",
            alertIcon: 'error',
            showConfirmButton: 'true',
            timer: false,
            ruta: 'login',
            login: false,
            role: req.session.role,
            pag: 'true'
        });
    }
});

app.get('/', (req, res) => {
    if (req.session.loggedin) {
        res.render('indexP', {
            login: true,
            name: req.session.name,
            role: req.session.role,
            pag: 'true'
        })
    } else {
        res.render('indexP', {
            login: false, role: req.session.role,
            pag: 'true'
        })
    }

})

app.get('/header', (req, res) => {
    if (req.session.loggedin) {
        res.render('header', {
            login: true,
            name: req.session.name,
            role: req.session.role,
            pag: 'true'
        })
    }
})

app.get('/logout', (req, res) => {

    req.session.destroy(() => {
        res.redirect('/');

    });
});
app.get('/products', (req, res) => {
    connection.query('SELECT * FROM productos', (error, results) => {
        if (error) {
            throw error;
        } else {
            if (req.session.loggedin) {
                res.render('productos', {
                    results: results,
                    login: true,
                    name: req.session.name, role: req.session.role,
                    pag: 'true'
                });
            } else {
                res.render('productos', {
                    results: results, login: false, name: req.session.name, role: req.session.role,
                    pag: 'true'
                })
            }

        }

    });

})


app.get('/carrito', (req, res) => {
    res.render('carrito', {
        login: true,
        name: req.session.name, role: req.session.role,
        pag: 'true'
    })
});
app.get('/addCart/:id', (req, res) => {
    const id = req.params.id;
    connection.query('SELECT * FROM productos WHERE id=?', [id], (error, results) => {
        if (error) {
            res.send('error')
            console.log(error);
        } else {
            res.send(results)
        }
    });

});

app.get('/img', (req, res) => {
    res.render('img');
});
app.get('/admin', (req, res) => {
    connection.query('SELECT * FROM productos', (error, results) => {
        if (error) {
            res.send(error)
        } else {
            res.render('admin', {
                results: results,
                login: true,
                name: req.session.name, role: req.session.role,
                pag: 'true'
            });
        }

    });
});

app.get('/add', (req, res) => {
    connection.query('SELECT * FROM productos', (error, results) => {
        if (error) {
            res.send(error)
        } else {
            res.render('agregar', {
                results: results,
                login: true,
                name: req.session.name, role: req.session.role,
                pag: 'true'
            });
        }

    });
});




app.post('/addProduct', (req, res) => {
    const name = req.body.name;
    const description = req.body.description;
    const price = req.body.price;
    console.log(req.file);
    if (req.file == undefined) {
        connection.query('SELECT * FROM productos', (error, results) => {
            res.render('admin', {
                results: results,
                alert: true,
                alertTitle: "Error",
                alertMessage: "Ingrese un formato de imagen valido",
                alertIcon: 'error',
                showConfirmButton: 'true',
                timer: false,
                ruta: '',
                login: true,
                name: req.session.name, role: req.session.role,
                pag: 'true'
            });
        });
    } else {
        connection.query('INSERT INTO productos SET ?', { nombre: name, descripcion: description, precio: price, rute: req.file.originalname }, (error, results) => {
            if (error) {
                res.send('error')
                console.log(error);
            } else {
                console.log(req.file.path);
                connection.query('SELECT * FROM productos', (error, results) => {
                    res.render('admin', {
                        results: results,
                        alert: true,
                        alertTitle: "Regitro exitoso",
                        alertMessage: "Producto registrado",
                        alertIcon: 'success',
                        showConfirmButton: 'false',
                        timer: 1500,
                        ruta: '',
                        login: true,
                        name: req.session.name, role: req.session.role,
                        pag: 'true'
                    });
                });
            }

        });
    }

});

app.get('/edit/:id', (req, res) => {
    const id = req.params.id;
    connection.query('SELECT * FROM productos WHERE id=?', [id], (error, results) => {
        if (error) {
            res.send('error')
            console.log(error);
        } else {
            //connection.query('SELECT * FROM productos', (error, results) => {
            res.render('edit', {
                product: results[0],
                login: true,
                name: req.session.name, role: req.session.role,
                pag: 'true'
            });

            //  });
        }
    });
})

app.post('/editP', (req, res) => {
    const id = req.body.id;
    const name = req.body.name;
    const description = req.body.description;
    const price = req.body.price;
    const rute = req.file;
    console.log(rute);
    if (rute == undefined) {
        connection.query('UPDATE productos SET ? WHERE id=?', [{ nombre: name, descripcion: description, precio: price }, id], (error, results) => {
            if (error) {
                res.send(error)
            } else {
                connection.query('SELECT * FROM productos', (error, results) => {
                    res.render('admin', {
                        results: results,
                        alert: true,
                        alertTitle: "Actualización exitosa",
                        alertMessage: "Producto actualizado correctamente",
                        alertIcon: 'success',
                        showConfirmButton: 'false',
                        timer: 2000,
                        ruta: '',
                        login: true,
                        name: req.session.name, role: req.session.role,
                        pag: 'true'
                    });
                })
            }
        })
    } else {
        connection.query('UPDATE productos SET ? WHERE id=?', [{ nombre: name, descripcion: description, precio: price, rute: req.file.originalname }, id], (error, results) => {
            if (error) {
                res.send(error)
            } else {
                // console.log(results);
                connection.query('SELECT * FROM productos', (error, results) => {
                    res.render('admin', {
                        results: results,
                        alert: true,
                        alertTitle: "Actualización exitosa",
                        alertMessage: "Producto actualizado correctamente",
                        alertIcon: 'success',
                        showConfirmButton: 'false',
                        timer: 2000,
                        ruta: '',
                        login: true,
                        name: req.session.name, role: req.session.role,
                        pag: 'true'
                    });
                })
            }
        })
    }

});

app.get('/delete/:id', (req, res) => {
    const id = req.params.id;

    connection.query('SELECT * FROM productos WHERE id=?',[id], (error, results) => {
                res.render('eliminar', {
                    results:results,
                    product: results,
                    login: true,
                    name: req.session.name, role: req.session.role,
                    pag: 'true'
                });
                console.log(results);
            })
    
});

app.get('/deleteP/:id', (req, res) => {
    const id = req.params.id;
    connection.query('DELETE FROM productos WHERE id=?', [id], (error, results) => {
        if (error) {
            res.send(error)
        } else {
            connection.query('SELECT * FROM productos', (error, results) => {
                res.render('admin', {
                    results: results,
                    alert: true,
                    alertTitle: "Eliminación",
                    alertMessage: "Producto eliminado correctamente",
                    alertIcon: 'success',
                    showConfirmButton: 'false',
                    timer: 2000,
                    ruta: '',
                    login: true,
                    name: req.session.name, role: req.session.role,
                    pag: 'true'
                });
            })
        }
    })
});

app.get('/login', (req, res) => {
    res.render('login', { login: false, role: req.session.role, pag: 'true' });
})

app.get('/register', (req, res) => {
    res.render('register', { login: false, role: req.session.role, pag: 'true' });
})

app.listen(3000, (req, res) => {
    console.log('http://localhost:3000');
})